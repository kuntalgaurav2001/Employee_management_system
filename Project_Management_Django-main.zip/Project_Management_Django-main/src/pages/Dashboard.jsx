import React from 'react'


const Dashboard = () => {
  return (
    <div>
        <div>
            <div>DashBoard</div>
        </div>
    </div>
  )
}

export default Dashboard;